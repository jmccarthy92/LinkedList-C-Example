#include <iostream> //we are adding ostream and istream
#include <cstdlib>
#include "bag.h"
using namespace std;

typedef int value_type;
typedef std::size_t size_type;
bag::bag(size_type initial_capacity) //set capacity, used, and do a dynamic array of value_type
{
	data = new value_type[initial_capacity];
	capacity = initial_capacity;
	used = 0;
}

bag::bag(const bag& source)
{
	capacity = source.capacity;
	data = new value_type[capacity];
	for (int x = 0; x < source.used; x++)
	{
		data[x] = source.data[x];
		used++;
	}
	
}
bag::~bag() //our destructor should release any dynamic memory we've allocated
{
	delete data;
}


void bag::reserve(size_type new_capacity) //we enlarge our bag, but it should still have the same contents
{
	value_type *newArr;
	newArr = new value_type[new_capacity];
	for (int x = 0; x < used; x++)
	{
		newArr[x] = data[x];
	//	used++;
	}
	delete data;
	data = newArr;
	capacity = new_capacity;
	
}

bool bag::erase_one(const value_type& target) //erases one item of a given value, returns true if something got erased, 0 if not
{
	bool deleteSwitch = false;
	for (int x = 0; x < used  ; x++)
	{
		if (data[x] == target || deleteSwitch == true)
		{
			deleteSwitch = true;
			data[x] = data[x + 1];
		}
	}
	if (deleteSwitch == true)
	{
		used--;
		return true;
	}
	return false;
}

size_type bag::erase(const value_type& target) //erases all of the data target from the bag
{
	size_type counter = 0;
	for (int x = 0; x < used; x++)
	{
		erase_one(target);
		counter++;
	}
	return counter;

}

void bag::insert(const value_type& entry) //inserts an entry into the bag
{


	if( used == capacity)
	{
	//	value_type *newArr;
	//	newArr = new value_type[capacity + 1];
	//	bag newBag
		reserve(capacity * 2);
	}

	data[used++] = entry;

}

void bag::operator +=(const bag& addend) //adds the contents of one bag to another
{
	for (int x = 0; x < addend.used; x++)
	{
		insert(addend.data[x]);
	}
}

void bag::operator =(const bag& source) //makes two bags equal
{

	for (int x = 0; x < source.used; x++)
	{
		data[x] = source.data[x];
	}
	used = source.used;
	capacity = source.capacity;

}

size_type bag::count(const value_type& target) const //returns how many things are currently in the bag
{
	size_type counter = 0;
	for (int x = 0; x < used; x++)
	{
		if (data[x] == target)
		{
			counter++;
		}
	}
	return counter;
}

ostream& operator <<(ostream& outs, const bag& source)
{
	for (unsigned int r = 0; r<source.used; r++)
	{
		outs << source.data[r] << ",";
	}
	//outs<<endl;
	return outs;
}